// Netlify runtime configuration
window.NETLIFY_RUNTIME = {
  deployed_at: "2025-03-12T06:20:42.982Z"
};